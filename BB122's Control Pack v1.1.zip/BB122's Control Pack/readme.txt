All your favorite Control styles, in a nice Minecraft-Style 16x16 pack.


If your going to use these controls for your game please credit "Babylion122" or
my channel on YouTube which is also Babylion122.

All of the art and buttons are made by Babylion122, no art from others are used
in this pack.

Current (v1.0)
Keyboard and Mouse
PlayStation 4
Xbox One and Series

UPCOMING
Nintendo Switch
Steam Deck
VR